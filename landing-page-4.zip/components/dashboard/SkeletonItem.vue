<template>
  <div
    class="flex flex-col w-full h-full bg-white dark:bg-gray-700 rounded-md py-4 px-5"
  >
    <div class="flex items-center w-full px-16 lg:px-44 md:px-44">
      <p
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      />
    </div>
    <div class="grid grid-cols-2 w-full gap-3 mt-3">
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
    </div>
    <div class="grid grid-cols-2 w-full gap-3 mt-3">
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
    </div>
    <div class="grid grid-cols-2 w-full gap-3 mt-3">
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
    </div>

    <div class="flex items-center w-full px-16 lg:px-44 md:px-44 mt-6">
      <p
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      />
    </div>
    <div class="grid grid-cols-2 w-full gap-3 mt-3">
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
    </div>
    <div class="grid grid-cols-2 w-full gap-3 mt-3">
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
    </div>
    <div class="grid grid-cols-2 w-full gap-3 mt-3">
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
      <div
        class="h-5 w-full bg-gray-300 dark:bg-gray-900 rounded-md animate-pulse"
      ></div>
    </div>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
